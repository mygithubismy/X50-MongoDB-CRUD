// initial
const path = require('path');
const hostname = '127.0.0.1';
const port = 80;

// express
const express = require('express');
const app = express();

// this codes is written in mongoose documentation(quik start)
// Note: first start mongod.
const mongoose = require('mongoose'); // installed mongoose module.
const { request } = require('http');
main().catch(err => console.log(err)); //  for error.
async function main() {await mongoose.connect('mongodb://127.0.0.1:27017/test')}; // to connect with mongod and database test.

// creating a schema
const testingSchema = new mongoose.Schema({
    name: String,
    password: String,
    content: String,
    private: String
});
// creating a model (a class). The 1st parameter is to select collection and 2nd is to select schema.
// collection name is 'c'
const testModel = mongoose.model('testmodel', testingSchema, 'c');

// These are the codes if it need to create documents at starting this file:
/*
testingSchema.methods.show = function show() {console.log(this.name)}; // created a show function.
const test = new testModel({name: 'test0'}); // a document by that class.
test.save(); // saving the document.
test.show(); // to check.
const log = testModel.find(); console.log(log); // to see all documents.
*/

// to using static files.
app.use('/static', express.static('static'));
app.use(express.urlencoded());

// to set view engine amd directory.
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

// for homepage request.
app.get('/', (req, res) => {
    res.status(200).render('index.pug');
});

// for create page request.
app.get('/create', (req, res) => {
    res.status(200).render('create.pug');
});
app.post('/create', async (req, res) => {
    try {
        let request = new testModel(req.body);
        let check = await testModel.findOne({ 'name': request.name });
        if (check) {
            res.send(`Error : The name '${request.name}' is already exists.`)
        } else {
            await request.save();
            res.send(`Done : Note is saved.`);
        }
    } catch (error) {
        console.error("Error(create) : ", error);
        res.status(400).send(`Error : Note is not saved due to this : ${error}`);
    }
    delete request;
    delete check;
});

// for read page request
app.get('/read', (req, res) => {
    res.status(200).render('read.pug');
});
app.post('/read', async (req, res) => {
    try {
        let request = new testModel(req.body);
        let check = await testModel.findOne({ 'name': request.name });
        if (check) {
            if (check.private) {
                if (check.password == request.password) {
                    res.send(`Content(private) : ${check.content}`);
                } else {
                    res.send(`Error : The password/name is not matching.`)
                }
            } else {
                res.send(`Content(public) : ${check.content}`);
            }
        } else {
            res.send(`Error : The note '${request.name}' does not exists. Check the name again.`);
        }
    } catch (error) {
        console.error("Error(read) : ", error);
        res.status(400).send(`Error : Can't read note due to this : ${error}`);
    }
    delete request;
    delete check;
});

// for edit page request
app.get('/edit', (req, res) => {
    res.status(200).render('edit.pug');
});
app.post('/edit', async (req, res) => {
    try {
        let request = new testModel(req.body);
        let check = await testModel.findOne({ 'name': request.name });
        if (check) {
            if (check.password == request.password) {
                res.status(200).render('write.pug', {check});
            } else {
                res.send(`Error : The password/name is not matching.`);
            }
        } else {
            res.send(`Error : The note '${request.name}' does not exists. Check the name again.`);
        }
    } catch (error) {
        console.error("Error(edit) : ", error);
        res.status(400).send(`Error : Can't get note due to this : ${error}`);
    }
    delete request;
    delete check;
});
app.post('/write', async (req, res) => {
    try {
        let request = new testModel(req.body);
        let check = await testModel.findById(request._id);
        if (check.password == request.password) {
            await testModel.findByIdAndUpdate(request._id, {'content' : request.content})
            res.send(`Done : Note updated`);
        } else {
            res.send(`Error : Hehe! how can you give this request without password? Improve the moral values.`)
        }
    } catch {
        console.error("Error(write) : ", error);
        res.status(400).send(`Error : Can't get data due to this : ${error}`);
    }
    delete request;
    delete check;
})

// for delete page request.
app.get('/delete', (req, res) => {
    res.status(200).render('delete.pug');
});
app.post('/delete', async (req, res) => {
    try {
        let request = new testModel(req.body);
        let check = await testModel.findOne({ 'name': request.name });
        if (check) {
            if (check.password == request.password) {
                await testModel.deleteOne({'name' : request.name});
                res.send(`Done : Note deleted.`);
            } else {
                res.send(`Error : The password/name is not matching`);
            }
        } else {
            res.send(`Error : The note '${request.name}' is already not exists. Check name again.`);
        }
    } catch (error) {
        console.error("Error(delete) : ", error);
        res.status(400).send(`Error : Can't get data due to this : ${error}`);
    }
    delete request;
    delete check;
});

// for confirmation.
app.listen(port, () => {
    console.log(`The application running at ${hostname}:${port}`);
});