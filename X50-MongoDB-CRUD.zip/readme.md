# X50-MongoDB-CRUD
 * In this project I made a platform where notes can be create/save, read, update/edit and delete by using MongoDB.
 * Make sure that mongod is already running as enviormental variable and then run app.js by NodeJS.